// JavaScript Document
function rePlace(obj){
	var oShopping=document.getElementsByClassName("shopping")[0];
	var oImg=oShopping.getElementsByClassName("girlImg")[0];
	var a=obj.cloneNode(true);
	var oImg1=a.firstElementChild;
	var oOl=document.getElementById("imgList");
	oShopping.insertBefore(oImg1,oOl);
	oImg1.className="girlImg";
	oShopping.replaceChild(oImg1,oImg);

}