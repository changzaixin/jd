// JavaScript Document


//创建模态层
function model(){
		var oM=document.createElement('div');
		oM.className="modal";
		document.body.appendChild(oM);
		return modelLayer=function(){
			oM.parentNode.removeChild(oM);
		}
}
//创建警告弹框
function alertbox(obj,msg,fn,fun){
	var modlayer=model();
	obj.className="alertbox";
	document.body.appendChild(obj);
    obj.innerHTML+='<p>'+msg+'</p><button type="button" class="ok">确认</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" class="cancel">取消</button>';
	var oalertBtn=obj.getElementsByTagName("button");
	showcenter(obj);
	drag(obj);
	oalertBtn[0].onclick=function(){
		fn&&fn();
	    modlayer();
		fun&&fun();
	}
	oalertBtn[1].onclick=function(){
		fn&&fn();
		modlayer();
	}
	oalertBtn[0].onmousedown=function(ev){
		ev.cancelBubble=true;
	}
	oalertBtn[1].onmousedown=function(ev){
		ev.cancelBubble=true;
	}
}


//每行span的个数，以及input.span的取值；
function aSpannum(a,flag){
	var aSpan=a.parentNode.parentNode.getElementsByTagName("span");
	var aInput=a.parentNode.parentNode.getElementsByTagName("input");
	var len2=aSpan.length;
	for(var z=0;z<len2;z++){
		flag? (aInput[z].value=aSpan[z].innerHTML):(aSpan[z].innerHTML=aInput[z].value);
	}
}


//tr中classname的取值；
function className(a,flag){
	a.parentNode.parentNode.className=flag?"edit":"";
}

