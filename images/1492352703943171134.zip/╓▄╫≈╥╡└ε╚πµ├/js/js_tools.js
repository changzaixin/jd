// JavaScript Document


//页面居中显示
function showcenter(obj){
	function center(){
		obj.style.left=(document.documentElement.clientWidth-obj.offsetWidth)/2+"px";
		obj.style.top=(document.documentElement.clientHeight-obj.offsetHeight)/2+"px";
	}
	center();
	window.onresize=center;
}



//拖拽
function drag(obj){
	obj.onmousedown=function(ev){
		var disX=ev.clientX-obj.offsetLeft;
		var disY=ev.clientY-obj.offsetTop;
		document.onmousemove=function(ev){
			var t=ev.clientY-disY;
			var l=ev.clientX-disX;
			var screenW=document.documentElement.clientWidth;
			var screenH=document.documentElement.clientHeight;
			if(l<0){
				l=0;
			}
			if(t<0){
				t=0;
			}
			if(l>screenW-obj.offsetWidth){ 
				l=screenW-obj.offsetWidth
			}
			if(t>screenH-obj.offsetHeight){ 
				t=screenH-obj.offsetHeight
			}
			obj.style.left=l+"px";
			obj.style.top=t+"px";
		}
		document.onmouseup=function(){
			document.onmousemove=null;
		}
		return false;//阻止默认事件
	};
};